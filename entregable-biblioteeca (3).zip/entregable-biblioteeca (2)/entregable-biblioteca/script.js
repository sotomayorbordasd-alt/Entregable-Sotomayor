// ===== Lista de libros (la usan las dos páginas) =====
const libros = [
  { titulo: "La ciudad y los perros", autor: "Mario Vargas Llosa", categoria: "Novela",   img: "img/ciudad-perros.jpg" },
  { titulo: "Rayuela",                autor: "Julio Cortázar",     categoria: "Novela",   img: "img/rayuela.jpg" },
  { titulo: "Ficciones",              autor: "Jorge Luis Borges",  categoria: "Cuentos",  img: "img/ficciones.jpg" },
  { titulo: "Los ríos profundos",     autor: "José María Arguedas", categoria: "Novela",  img: "img/rios-profundos.jpg" },
  { titulo: "Pedro Páramo",           autor: "Juan Rulfo",         categoria: "Novela",   img: "img/pedro-paramo.jpg" },
  { titulo: "El Principito",          autor: "Antoine de Saint-Exupéry", categoria: "Infantil", img: "img/principito.jpg" }
];

// ===== Menú del celular =====
const menuBtn = document.getElementById("menuBtn");
const menu = document.getElementById("menu");
menuBtn.addEventListener("click", function () {
  menu.classList.toggle("abierto");
});

// ===== Catálogo: mostrar, buscar y filtrar =====
const listaLibros = document.getElementById("listaLibros");

function mostrarLibros(lista) {
  listaLibros.innerHTML = "";
  lista.forEach(function (libro) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "tarjeta";
    tarjeta.innerHTML =
      '<img src="' + libro.img + '" alt="Portada de ' + libro.titulo + '">' +
      "<h3>" + libro.titulo + "</h3>" +
      '<p class="autor">' + libro.autor + "</p>" +
      '<button class="btn" data-libro="' + libro.titulo + '">Reserva</button>';
    listaLibros.appendChild(tarjeta);
  });
  document.getElementById("sinResultados").hidden = lista.length > 0;
}

function filtrarLibros() {
  const texto = document.getElementById("buscador").value.toLowerCase().trim();
  const cat = document.getElementById("categoria").value;

  const resultado = libros.filter(function (libro) {
    const coincideTexto =
      libro.titulo.toLowerCase().includes(texto) ||
      libro.autor.toLowerCase().includes(texto);
    const coincideCat = cat === "todas" || libro.categoria === cat;
    return coincideTexto && coincideCat;
  });
  mostrarLibros(resultado);
}

// solo corre en catalogo.html (en index no existe la lista)
if (listaLibros) {
  mostrarLibros(libros);
  document.getElementById("buscador").addEventListener("input", filtrarLibros);
  document.getElementById("categoria").addEventListener("change", filtrarLibros);
}

// ===== Formulario de reserva =====
const modal = document.getElementById("modalReserva");
const form = document.getElementById("formReserva");
const selectLibro = document.getElementById("libro");
const inputFecha = document.getElementById("fecha");
const mensajeOk = document.getElementById("mensajeOk");

// llenar el select con los libros
selectLibro.innerHTML = '<option value="">Elige un libro</option>';
libros.forEach(function (libro) {
  selectLibro.innerHTML += '<option value="' + libro.titulo + '">' + libro.titulo + "</option>";
});

// la fecha mínima es hoy
function fechaHoy() {
  const hoy = new Date();
  const mes = String(hoy.getMonth() + 1).padStart(2, "0");
  const dia = String(hoy.getDate()).padStart(2, "0");
  return hoy.getFullYear() + "-" + mes + "-" + dia;
}
inputFecha.min = fechaHoy();

function abrirModal(tituloLibro) {
  form.reset();
  limpiarErrores();
  mensajeOk.textContent = "";
  if (tituloLibro) selectLibro.value = tituloLibro;
  mostrarReservas();
  modal.showModal();
}

// botones "Reserva" (los de las tarjetas y el del menú)
document.addEventListener("click", function (e) {
  const botonLibro = e.target.closest("[data-libro]");
  const enlaceMenu = e.target.closest("[data-reserva]");

  if (botonLibro) {
    abrirModal(botonLibro.dataset.libro);
  } else if (enlaceMenu) {
    e.preventDefault();
    abrirModal("");
  }
});

document.getElementById("btnCerrar").addEventListener("click", function () {
  modal.close();
});

// ===== Validaciones =====
function ponerError(idCampo, idError, mensaje) {
  document.getElementById(idError).textContent = mensaje;
  document.getElementById(idCampo).classList.add("invalido");
}

function limpiarErrores() {
  document.querySelectorAll(".error").forEach(function (el) { el.textContent = ""; });
  document.querySelectorAll(".invalido").forEach(function (el) { el.classList.remove("invalido"); });
}

function validarFormulario() {
  limpiarErrores();
  let valido = true;

  const nombre = document.getElementById("nombre").value.trim();
  const correo = document.getElementById("correo").value.trim();
  const libro = selectLibro.value;
  const fecha = inputFecha.value;

  // nombre: no vacío y mínimo 3 letras
  if (nombre === "") {
    ponerError("nombre", "errNombre", "Escribe tu nombre completo.");
    valido = false;
  } else if (nombre.length < 3) {
    ponerError("nombre", "errNombre", "El nombre debe tener al menos 3 letras.");
    valido = false;
  }

  // correo: no vacío y con formato válido
  const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (correo === "") {
    ponerError("correo", "errCorreo", "Escribe tu correo electrónico.");
    valido = false;
  } else if (!formatoCorreo.test(correo)) {
    ponerError("correo", "errCorreo", "El correo no es válido (ejemplo: ana@correo.com).");
    valido = false;
  }

  // libro: tiene que elegir uno
  if (libro === "") {
    ponerError("libro", "errLibro", "Elige el libro que quieres reservar.");
    valido = false;
  }

  // fecha: obligatoria y no puede ser anterior a hoy
  if (fecha === "") {
    ponerError("fecha", "errFecha", "Elige la fecha en que recogerás el libro.");
    valido = false;
  } else if (fecha < fechaHoy()) {
    ponerError("fecha", "errFecha", "La fecha no puede ser anterior a hoy.");
    valido = false;
  }

  return valido;
}

// ===== localStorage =====
function leerReservas() {
  try {
    return JSON.parse(localStorage.getItem("reservas")) || [];
  } catch (error) {
    return [];
  }
}

function guardarReservas(reservas) {
  localStorage.setItem("reservas", JSON.stringify(reservas));
}

function mostrarReservas() {
  const lista = document.getElementById("listaReservas");
  const reservas = leerReservas();
  lista.innerHTML = "";

  if (reservas.length === 0) {
    lista.innerHTML = '<li class="sin-reservas">Todavía no tienes reservas.</li>';
    return;
  }

  reservas.forEach(function (r, i) {
    const li = document.createElement("li");
    li.innerHTML =
      "<div><strong>" + r.libro + "</strong>" +
      "<span>" + r.nombre + " · recojo: " + r.fecha + "</span></div>" +
      '<button class="quitar" data-quitar="' + i + '" aria-label="Cancelar reserva">Quitar</button>';
    lista.appendChild(li);
  });
}

// cancelar una reserva
document.getElementById("listaReservas").addEventListener("click", function (e) {
  const boton = e.target.closest("[data-quitar]");
  if (!boton) return;
  const reservas = leerReservas();
  reservas.splice(Number(boton.dataset.quitar), 1);
  guardarReservas(reservas);
  mostrarReservas();
});

// enviar el formulario
form.addEventListener("submit", function (e) {
  e.preventDefault();
  if (!validarFormulario()) return;

  const reservas = leerReservas();
  reservas.push({
    nombre: document.getElementById("nombre").value.trim(),
    correo: document.getElementById("correo").value.trim(),
    libro: selectLibro.value,
    fecha: inputFecha.value
  });
  guardarReservas(reservas);

  const libroReservado = selectLibro.value;
  form.reset();
  mensajeOk.textContent = "¡Listo! Reservaste \"" + libroReservado + "\".";
  mostrarReservas();
});
